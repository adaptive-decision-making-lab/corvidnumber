library(readr)
library(stringr)

# Copy files from project directory
file.copy("~/active_sync/projects/corvid_number/biology_letters_paper/data/wolff_etal_2022_data.csv", "wolff_etal_2022_data.csv", overwrite = TRUE)
file.copy("~/active_sync/projects/corvid_number/biology_letters_paper/R/wolff_etal_2022_rcode.R", "R/wolff_etal_2022_rcode.R", overwrite = TRUE)
file.copy("~/active_sync/projects/corvid_number/biology_letters_paper/docs/wolff_etal_2022.Rmd", "docs/wolff_etal.Rmd", overwrite = TRUE)
file.copy("~/active_sync/projects/corvid_number/biology_letters_paper/docs/wolff_etal_2022_SM.qmd", "docs/wolff_etal_2022_SM.qmd", overwrite = TRUE)
file.copy("~/active_sync/projects/corvid_number/biology_letters_paper/figures/food_apparatus.png", "figures/food_apparatus.png", overwrite = TRUE)
file.copy("~/active_sync/projects/corvid_number/biology_letters_paper/figures/social_apparatus.png", "figures/social_apparatus.png", overwrite = TRUE)
file.copy("~/active_sync/projects/corvid_number/biology_letters_paper/figures/wolff_etal_2022.mp4", "wolff_etal_2022.mp4", overwrite = TRUE)
file.copy("~/active_sync/projects/corvid_number/biology_letters_paper/docs/merp_references.bib", "wolff_etal_2022.bib", overwrite = TRUE)
file.copy("~/active_sync/projects/corvid_number/biology_letters_paper/docs/r-references.bib", "r-references.bib", overwrite = TRUE)
file.copy("~/active_sync/projects/corvid_number/biology_letters_paper/docs/prsb.csl", "wolff_etal_2022.csl", overwrite = TRUE)
file.copy("~/active_sync/projects/corvid_number/biology_letters_paper/docs/apa7_chron.csl", "wolff_etal_2022b.csl", overwrite = TRUE)
file.copy("~/active_sync/projects/corvid_number/biology_letters_paper/README.md", "README.md", overwrite = TRUE)

# Edit R script
r_code <- read_file("R/wolff_etal_2022_rcode.R") |>
  # str_replace("stevens_etal_", "stevens_etal_2021_") |>
  str_replace("library\\(here\\)", "") |>
  str_replace('read_csv\\(here\\("data/wolff_etal_2022_data.csv"\\)\\)', 'read_csv\\("wolff_etal_2022_data.csv"\\)') |>
  str_replace_all("\\(here\\(", "\\(") |>
  str_replace_all('.png"\\),', '.png",') |>
  str_replace_all('.RData"\\)', '.RData"') |>
  str_replace_all('save.image', '# save.image') |>
  write_file("wolff_etal_2022_rcode.R")
source("wolff_etal_2022_rcode.R")

# Edit manuscript
manuscript <- read_file("docs/wolff_etal.Rmd") |>
  str_replace_all("merp_references.bib", "wolff_etal_2022.bib") |>
  str_replace_all("biology-letters.csl", "wolff_etal_2022.csl") |>
  str_replace('source\\(here\\("R/wolff_etal_2022_rcode.R"\\)\\)', 'source\\("wolff_etal_2022_rcode.R"\\)') |>
  str_replace_all(" Figure used with permission under a CC-BY4.0 license: Wolff et al. \\(2022\\); available at https://doi.org/10.31234/osf.io/kxgwt.", "") |>
  # str_replace_all("Table used with permission under a CC-BY4.0 license: Wolff, Carey, & Stevens (2022); available at https://doi.org/10.31234/osf.io/????.", "") |>
  str_replace_all("lineno            : yes", "lineno            : no") |>
  str_replace("authornote: \\|", paste("authornote: \\|\n\  PsyArXiv: https://doi.org/10.31234/osf.io/kxgwt\n\n\  Version:", Sys.Date(), "\n")) |>
  str_replace_all(": \"doc\"", ": \"pub\"") |>
  str_replace_all(": \"man\"", ": \"pub\"") |>
  str_replace_all('out.width="100%"', 'out.width="90%"') |>
  str_replace_all('fig.align="center"', 'fig.align = "center", fig.env = \"figure*\"') |>
  # str_replace_all('out.width = "33\\%"', 'out.width = "30\\%"') |>
  str_replace_all("\\\\newpage", "") |>
  # str_replace_all("\\\\clearpage", "") |>
  str_replace("# References", "# References\n\\\\scriptsize") |>
  write_file("wolff_etal_2022_preprint.Rmd")
# rmdfile <- read_lines("wolff_etal_2022.Rmd")
# sm_line <- which(rmdfile == "# Supplementary Materials") - 1
# max_line <- length(rmdfile)
# rmd_file <- rmdfile[-(sm_line:max_line)]
# write_lines(rmd_file, "wolff_etal_2022.Rmd")
rmarkdown::render("wolff_etal_2022_preprint.Rmd")
# file.copy("wolff_etal_2022.pdf", "wolff_etal_2022_all.pdf", overwrite = TRUE)
# pdf_subset("wolff_etal_2022_all.pdf", pages = 1:15, output = "wolff_etal_2022.pdf")

# Edit supplementary materials
qmdfile <- read_lines("docs/wolff_etal_2022_SM.qmd") |>
  str_replace("library\\(here\\)", "") |>
  str_replace('here\\("R/wolff_etal_2022_rcode.R"\\)', '"wolff_etal_2022_rcode.R"') |>
  str_replace('apa7_chron.csl', 'wolff_etal_2022b.csl') |>
  str_replace("here\\(", "") |>
  str_replace('.png"\\)\\)', '.png"\\)') |>
  str_replace("merp_references.bib", "wolff_etal_2022.bib") |>
str_replace_all(" Figure used with permission under a CC-BY4.0 license: Wolff et al. \\(2022\\); available at \\[https://doi.org/10.31234/osf.io/kxgwt\\]\\(https://doi.org/10.31234/osf.io/kxgwt\\).", "") |>
write_lines("wolff_etal_2022_SM.qmd")
# rmarkdown::render("wolff_etal_2022_SM.Rmd")
quarto::quarto_render("wolff_etal_2022_SM.qmd")

# Create zip file
zip(zipfile = "wolff_etal_2022_rr", files = c("r-references.bib", "README.md", "wolff_etal_2022_data.csv", "wolff_etal_2022_rcode.R", "wolff_etal_2022_SM.pdf", "wolff_etal_2022.bib", "wolff_etal_2022.csl", "wolff_etal_2022b.csl", "wolff_etal_2022_preprint.pdf", "wolff_etal_2022_preprint.Rmd"))


library(osfr)

# Load project and components
corvid_number_project <- osf_retrieve_node("https://osf.io/g45nk/")
corvid_number_data <- osf_retrieve_node("https://osf.io/5nprq/")
corvid_number_figures <- osf_retrieve_node("https://osf.io/cjsx6/")
corvid_number_preprint <- osf_retrieve_node("https://osf.io/tkqxd/")

# Upload data
data_files <- osf_upload(corvid_number_data, path = "wolff_etal_2022_data.csv", conflicts = "overwrite")

# Upload R script and README
readme <- osf_upload(corvid_number_data, path = "README.md", conflicts = "overwrite")
rscript <- osf_upload(corvid_number_data, path = "wolff_etal_2022_rcode.R", conflicts = "overwrite")

# Upload figures
figures <- osf_upload(corvid_number_figures, path = list.files(path = "figures", pattern = "png", full.names = TRUE), conflicts = "overwrite")
osf_upload(corvid_number_figures, path = "wolff_etal_2022.mp4", conflicts = "overwrite")

# Upload preprint
# osf_upload(corvid_number_preprint, path = c("wolff_etal_2022_preprint.pdf"), conflicts = "overwrite")
preprint <- osf_upload(corvid_number_preprint, path = c("wolff_etal_2022_preprint.Rmd", "wolff_etal_2022_preprint.pdf", "wolff_etal_2022_SM.qmd", "wolff_etal_2022_SM.pdf"), conflicts = "overwrite")
